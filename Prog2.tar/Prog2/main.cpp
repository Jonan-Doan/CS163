#include"queue.h"
using namespace std; 
int main()
{
	  queue info_packages;// object to hold the infomation of the packages
	  packages new_packages, an_entry;// hold a new package's name, phone, and id
	  char sender_name_toadd[200];// static array that will hold the name of the sender of the package
	  char id_toadd[300];// static array that will hold the id of the package
	  char phone_toadd[300];// static array that will hold phone number of the sender 
	  char address_toadd[300];// static array that will hold the address where the package will be sent 
	  char response;// char variable that will hold the letter if the user want to repeat their choice
	  char choice;// char variable that will hold the  letter of what the user want to do for the program
	  int error = 0;// int variable that will prompt if there is something wrong with the program
	  do
	  { 
		  cout<<"Please enter A to add a new packages to be shipped, R if you want to remove a particular package,"
		  <<" D if you want to display all of the packages."<<endl<<endl;
		  cin>>choice;
		  cin.ignore(100, '\n');
		  choice=toupper(choice);
		  if(choice == 'A') //if they want to add a new package 
		  {
			  do
			  {
				  
				  cout<<"Please enter your name."<<endl;
				  cin.get(sender_name_toadd, 200); cin.ignore(100, '\n');
				  cout<<"Please enter the package identification number"<<endl;
				  cin.get(id_toadd, 300); cin.ignore(100, '\n');
				  cout<<"Please enter the your phone number."<<endl;
				  cin.get(phone_toadd, 300); cin.ignore(100, '\n');
				  new_packages.create_entry(sender_name_toadd, phone_toadd, id_toadd);
				  cin.get(address_toadd, 300); cin.ignore(100, '\n');
				  error= info_packages.enqueue(address_toadd, new_packages); 
				  if(error == 0)
				  {
					  cout<<"Please type again. The information can not be added."<<endl<<endl;
				  }  
				  
				
				  cout<<"Please enter Y if you want to add another package and enter N if you don't want to add another package."<<endl<<endl;
				  cin>>response;
				  cin.ignore(100, '\n');
				  response=toupper(response);
			  }while(response== 'Y');
		  }
		  if(choice == 'R') // if they want to remove a package
		  {
			  do
			  {
				  error= info_packages.dequeue();
				  if(error == 0)
				  {
					  cout<<"There is no packages to be deleted."<<endl<<endl;
				  }
				  
				  cout<<"Please enter Y if you want to remove another package and enter N if you don't want to remove another package."<<endl<<endl;
				  cin>>response;
				  cin.ignore(100, '\n');
				  response=toupper(response);
			  }while(response== 'Y');
		  }
		  if(choice == 'D')// if they want to display a package
		  {
			  cout<<"The conent of the package is: "<<endl<<endl;
			  info_packages.display_all_queue();
		  }

			  
	}while(choice != 'Q');// end program once user had type q

}


