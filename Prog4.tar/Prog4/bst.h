#include "song.h"
//organized data in a binary search tree
class tree
{
	public:
		tree();//default constructor
		~tree();//default destructor
		bool add_song(const music_entry & new_song, char artist_compare[]);// wrapper function for add_song function
		bool search(char keyword1_search[],char keyword2_search[],char keyword3_search[]);//wrapper function for the search function
		int destroyhelper(node * root);//wrapper function for destroyhelper function
		bool remove(char name_to_remove[]);//wrapper function for destroyhelper funcntion
		bool display_match(char keyword1_display[],char keyword2_display[],char keyword3_display[]);//wrapper function for display_match function
		int get_height();//wrapper function for get_height functgion
		bool is_efficient();//wrapper function for  is_efficient function
		bool display_all();//wrapper function for display all
		bool read_file();//read in the file data and add the data to the binary search tree
 
	private:
		node * root;
		bool add_song(node *& root, const music_entry & new_song, char artist_compare[]);// add a new song entry to a binary search tree
		bool search(node * root, char keyword1_search[],char keyword2_search[],char keyword3_search[]);//search if there is a keyword in a binary search tree
		bool remove_node(node *& root);//remove the node
		bool removeHelper(char name_to_remove[], node *& root);//helper for the remove node function
		bool display_match(node * root, char keyword1_display[],char keyword2_display[],char keyword3_display[]);//display a matching song based on its keyword
		int get_height(node * root);//get the height of the tree
		bool is_efficient(node * root);//check if the binary search tree is balanced
		bool display_all(node * root);//display all the content in the binary search tree

};


