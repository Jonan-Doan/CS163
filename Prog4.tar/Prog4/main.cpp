#include"bst.h"
using namespace std; 
int main()
{
	  tree my_song;// object of the hash_table class
	  music_entry to_add, an_entry; //object of the music_entry class
	  char artist[ARTIST_SIZE];//array that hold the artist name
	  char song[SONG_SIZE];//array that hold the song title name
	  char album[ALBUM_SIZE];//array that hold the album neme
	  char keyword1[KEYWORDS_SIZE];//array that hold the keyword1
	  char keyword2[KEYWORDS_SIZE];//array that hold the keyword2
	  char keyword3[KEYWORDS_SIZE];//arraty that hold the keyword3
	  char descriptions[DESCRIPTION_SIZE];//array that hold the descriptions of the song
	  char response;// char variable that will hold the letter if the user want to repeat their choice
	  char choice;// char variable that will hold the  letter of what the user want to do for the program
	  bool error = false;// bool variable that will prompt if there is something wrong with the program
	  int height = 0;
	  do
	  { 
		  cout<<"Please type I if you want to insert a new data, please type R if you want to remove a data, please type S if you want to seacrch for a"
		  <<" data, please type L if you want to load pre-existing data ,please type D if you want to display all the data, Please type E if you want"
		  <<" to want to check if the binary search tree is efficient, Please type H to find the height of the binary search tree."<<endl<<endl;
		  cin>>choice;
		  cin.ignore(100, '\n');
		  choice=toupper(choice);
		  if(choice == 'I')//if the user want to insert
		  {
			  do
			  {
				  //get data
				  //

				  cout<<"Please type a artist name: ";
				  cin.get(artist, ARTIST_SIZE); cin.ignore (100, '\n');
				  cout<<"Please enter the song title: ";
				  cin.get(song, SONG_SIZE); cin.ignore(100, '\n');
				  cout<<"Please enter the album name: ";
				  cin.get(album, ALBUM_SIZE); cin.ignore (100, '\n');
				  cout<<"Please type three keywords that relate to the song"<<endl;
				  cout<<"Keyword 1: ";
				  cin.get(keyword1, KEYWORDS_SIZE); cin.ignore(100, '\n');
				  cout<<"Keyword 2: ";
				  cin.get(keyword2, KEYWORDS_SIZE); cin.ignore(100, '\n');
				  cout<<"Keyword 3: ";
				  cin.get(keyword3, KEYWORDS_SIZE); cin.ignore(100, '\n');
				  cout<<"Please enter the description for the song."<<endl;
				  cin.get(descriptions, DESCRIPTION_SIZE); cin.ignore(100, '\n');
				  
				  //pass in data to the initializer
				  to_add.initialize(artist,album, song, keyword1, keyword2, keyword3, descriptions);

				 //pass in the object to_add along with the keyword to insert
				  error= my_song.add_song(to_add, artist);
				  if(error == false)
				  {
					  cout<<"There were something wrong about the program please type again."<<endl;
				  }
				  cout<<"Please type Y if you want to add insert another item and type N if you don't want to add another item."<<endl;
				  cin>>response;
				  cin.ignore(100, '\n');
				  response= toupper(response);
			  }while(response== 'Y');//repeat if the user want to type again
		  }
		  if(choice == 'R')
		  {
			do
			{
				//get artist name
				cout<<"Please type a artist to remove a song based on its artist."<<endl;
				cin.get(artist, ARTIST_SIZE); cin.ignore (100, '\n');

				//pass in the artist name to the remove function
				error = my_song.remove(artist);
				if(error == false)//if there is an error
				{
				  cout<<"There was somthing wrong when adding a new item please type again."<<endl<<endl;//prompt user for error
				}
				  cout<<"Please type Y if you want to remove another item and please type N if you don't want to remove another item"
				  <<endl;//if they want to add a new item
				  cin>>response;
				  cin.ignore(100, '\n');
				  response= toupper(response);
			}while(response== 'Y');//repeat if they want to type again
		  }
		  if(choice == 'D')
		  {
			error= my_song.display_all();
			if(error == false)
			{
				cout<<"There are no item to display."<<endl;
			}
		  }
		  if(choice == 'S')
		  {
			  do
			  {
				  cout<<"Please type three keywords that relate to the song"<<endl;
				  cout<<"Keyword 1: ";
				  cin.get(keyword1, KEYWORDS_SIZE); cin.ignore(100, '\n');
				  cout<<"Keyword 2: ";
				  cin.get(keyword2, KEYWORDS_SIZE); cin.ignore(100, '\n');
				  cout<<"Keyword 3: ";
				  cin.get(keyword3, KEYWORDS_SIZE); cin.ignore(100, '\n');
				  error = my_song.search(keyword1, keyword2, keyword3);
				  if(error == false)//if there is an error
				{
					cout<<"The keywords is not found please type again."<<endl<<endl;
			       	}
				  my_song.display_match(keyword1, keyword2, keyword3);
				  cout<<"Please type Y if you want to search for another item and please type N if you don't want to search for another item."
				  <<endl;//if they want to add a new item
				  cin>>response;
				  cin.ignore(100, '\n');
				  response= toupper(response);
			}while(response== 'Y');//repeat if they want to type again
		  }
		  if(choice == 'L')
		  {
			  my_song.read_file();
		  }
		  if(choice == 'E')
		  {
			  error = my_song.is_efficient();
			  if(error == false)// if it is false it is not efficient
			  {
				  cout<<"The binary search tree is not efficient."<<endl<<endl;
			  }
			  else//else efficient
			  {

				  cout<<"The binary search tree is efficient."<<endl<<endl;
			  }
		  }
		  if(choice == 'H')
		  {
			  height = my_song.get_height();
			  cout<<"The height of the binary search tree is: "<<height<<endl<<endl;
		  } 




	  }while(choice != 'Q');
	  return 0;
}
