#include "bst.h"
//initialize the root node to Null
tree::tree()
{
	root = NULL;
}
//Helps deallocate memory for the destructor
int tree::destroyhelper(node * root)
{
	if(root)
	{
		destroyhelper(root->left);
		destroyhelper(root->right);
		delete root;
	}
}
//if the root has not be deallocated call the destroyhelper function
tree::~tree()
{
	if (root)
	{
		destroyhelper(root);
	}
}
//wrapper function for adding a song
bool tree:: add_song(const music_entry & new_song, char artist_compare[])
{
	return add_song(root, new_song, artist_compare);
}

//add data to the binary search tree either at the left branch or right branch
bool tree::add_song(node *&root, const music_entry& new_song, char artist_compare[])
{
	if(!root)
	{
		root = new node;
		if(!root->entry.copy(new_song))
		{
			return false;
		}
		root->left = root->right = NULL;
		return true;
	}
	if(root->entry.artist_less_than(artist_compare)== true)
	{
		add_song(root->left, new_song, artist_compare);
	}
	else
	{
		add_song(root->right, new_song, artist_compare);
	}
}
//wrapper function for search function
bool tree::search(char keyword1_search[],char keyword2_search[],char keyword3_search[])
{
	return search(root, keyword1_search, keyword2_search, keyword3_search);
}
//traverse either left branch or right branch to see if the keywords is in the binary search tree
bool tree::search(node * root, char keyword1_search[],char keyword2_search[],char keyword3_search[])
{
	if(!root) return false;
	else if(root->entry.keywords_match(keyword1_search, keyword2_search, keyword3_search) == true)
	{
		return true;
	}
	else if(root->entry.keywords_less_than(keyword1_search, keyword2_search, keyword3_search) == true)
	{
		search(root->left, keyword1_search, keyword2_search, keyword3_search);
	}
	else
	{
		search(root->right, keyword1_search, keyword2_search, keyword3_search);
	}
}
//Wrapper function for display all function
bool tree::display_all()
{
	
	return display_all(root);
}

//display all the content of the binary search tree
bool tree::display_all(node * root)
{
	if(!root) return false;
	display_all (root->left);
	root->entry.display();
	display_all(root->right);
	return true;
}

//wrapper function for displaying a match based on its keyword
bool tree::display_match(char keyword1_display[],char keyword2_display[],char keyword3_display[])
{
	return display_match(root, keyword1_display, keyword2_display, keyword3_display);
}
// display a match based on its keyword by checking the left branch and right branch
bool tree::display_match(node * root, char keyword1_display[],char keyword2_display[],char keyword3_display[])
{
	if(!root) return 0;
	display_match(root->left, keyword1_display, keyword2_display, keyword3_display);
	if(root->entry.keywords_match(keyword1_display, keyword2_display, keyword3_display) == true)
	{
		root->entry.display();
	}
	display_match(root->right, keyword1_display, keyword2_display, keyword3_display);
}
//wrapper function for removeHelper function
bool tree::remove(char name_to_remove[])
{
	return (removeHelper(name_to_remove,  root));
}
//traverse the left branch and right branch until there is a match
bool tree::removeHelper(char name_to_remove[], node *& root)
{
	if(!root) return false;
	else if (root->entry.artist_match(name_to_remove)== true)
	{
		return (remove_node(root));
	}
	else if(root->entry.artist_less_than(name_to_remove) == true)
	{
		removeHelper(name_to_remove, root->left);	
	}
	else
	{
		removeHelper(name_to_remove, root->right);
	}
}
//remove the node base on its position
bool tree::remove_node(node *& root)
{
	node * temp = root;
	if((root->left == NULL) && (root->right == NULL))
		root = NULL;
	else if (root->left == NULL)
		root = root->right;
	else if (root->right == NULL)
		root = root->left;
	else
	{
		node * parent = root;
		temp = root->right;
		while(temp->left != NULL)
		{
			parent = temp;
			temp = parent->left;
		}

		if(parent == root)
			parent->right = temp->right;
		else
			parent->left = temp->right;
		root->entry = temp->entry;
	}
	delete temp;
	return true;
}
//wrapper function to get the height of the tree	
int tree::get_height()
{
	return get_height(root);
}
//increment everytime the bst traverse
int tree::get_height(node * root)
{
	if(!root) return 0;
	else
		return 1 + max(get_height(root->left), get_height(root->right));
}
//wrapper function for is-efficient function
bool tree::is_efficient()
{
	return is_efficient(root);
}
//traverse the left branch and the right branch to get the value and if the absoule value between the right and left height is greater than 1 it is efficient
bool tree::is_efficient(node * root)
{
	if(!root) return false;
	int left_height = is_efficient(root->left);
	int right_height= is_efficient(root->right);
	int total = left_height - right_height;
	if(total < 0)
	{
		total = total * -1;
	}
	if (total > 1)
		return false;
	else
		return true;
}
//read information from a file store it into array than pass the information to add_song function
bool tree::read_file()
{
	ifstream in_file;
	in_file.open("songselect.txt");
	if(in_file)
	{
		while(in_file && in_file.peek() != EOF)
		{
			music_entry file_initialize;
			tree file_add;	
			char artist_read[100];
			char song_read[100];
			char album_read[100];
			char keyword1_read[100];
			char keyword2_read[100];
			char keyword3_read[100];
			char description_read[100];
			in_file.get(artist_read, 100, '|');
			in_file.ignore(100, '|');
			in_file.get(song_read, 100, '|');
			in_file.ignore(100, '|');
			in_file.get(album_read, 100, '|');
			in_file.ignore(100, '|');
			in_file.get(keyword1_read, 100, '|');
			in_file.ignore(100, '|');
			in_file.get(keyword2_read, 100, '|');
			in_file.ignore(100, '|');
			in_file.get(keyword3_read, 100, '|');
			in_file.ignore(100, '|');
			in_file.get(description_read, 100, '|');
			in_file.ignore(100, '|');
			file_initialize.initialize(artist_read,album_read, song_read, keyword1_read, keyword2_read, keyword3_read, description_read);
			file_add.add_song(file_initialize, artist_read);
		}
	}
}
