#include <iostream>
#include <cctype>
#include<fstream>
#include <cstring>
#include <string.h>
using namespace std;

//Jonan Doan
//The program design is to ask the user if they want to display, search,insert, remove , load, check if the tree is balanced or find the height of the binary search tree. If they want to display the program will
//display all the content of the binary search tree. If they want to search, the application will search for a particular matching node and display its content. If they want to insert than the program will insert the data
//based on the name of the artist. if they want to remove the program will ask the user to type a artist name and remove data connecting to the artist. If they want to load th program will read the data from external data file
//it will load the content of the file and add it into the binary search tree, if they want to check the efficiency of the binary search tree the program will find the difference of the left height and the right height and
//check if it  is efficient, if they want to know the height of the tree the user will recieve the integer value of what is the height of the binary search tree.
const int ARTIST_SIZE = 40;//constant size for the artist
const int SONG_SIZE = 40;//constant size for the song
const int ALBUM_SIZE = 40;//const size for the album
const int KEYWORDS_SIZE= 40;//const size for each keyword
const int DESCRIPTION_SIZE= 40;//const size for the description
const char outfile[]= "songselect.txt";//create a file called songselect.txt
// class that organizes implementation of dynamic array information

class music_entry
{
	public:
		music_entry();//default constructor
		~music_entry();//default destructor
		bool initialize(char artist_toadd[], char song_toadd[], char album_toadd[], char keyword1_toadd[], char keyword2_toadd[], char keyword3_toadd[], char description_toadd[]);//initialize each dynamic array to hold
		//the static array being passed in
		bool copy(const music_entry & entry);//copy all the data of the initialize function and copy it into an music_entry object
		bool compare_artist(char to_compare[]);//return the value if there is a match found between the artist name the user is searching for and pre-existing artist
		bool display() const;//display each information of the song
		bool keywords_match(char keyword1[],char keyword2[],char keyword3[]);//return true if there is a match
		bool artist_match(char artist_tocompare[]);//return true if the artist match
		bool artist_less_than(char artist_compare[]);//return true if artist in the binary search tree is greater than the new artist
		bool keywords_less_than(char keyword1_compare[],char keyword2_compare[], char keyword3_compare[]);
	private:
		char * artist;//pointer that hold the name of the artist
		char * song;//poointer that hold the song title
		char * album;//pointer that hold the album name
		char * keyword1;//pointer that hold keyword1
		char * keyword2;//pointer that hold keyword2
		char * keyword3;//pointer that hold keyword3
		char * descriptions;//pointer that hold the description of the song
};
struct node
{
	music_entry entry;//hold on to the entry of a song
	node * left;//hold on to the left branch of the binary search tree
	node * right;//hold on to the right branch of the binary search tree
};
