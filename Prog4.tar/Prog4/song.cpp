#include "song.h"
//initialize all the information of the song to NULL
music_entry::music_entry()
{
	artist= NULL;
	song= NULL;
	album= NULL;
	keyword1 = NULL;
	keyword2 = NULL;
	keyword3 = NULL;
	descriptions= NULL;
} 
//deallocate all memory of the information of the song
music_entry::~music_entry()
{
	if(artist)
	{
		delete[] artist;
		artist = NULL;
	}
	if(song)
	{
		delete[] song;
		song = NULL;
	}
	if(album)
	{
		delete[]album;
		album = NULL;

	}
	if(keyword1)
	{
		delete[]keyword1;
		keyword1= NULL;
	}
	if(keyword2)
	{
		delete[]keyword2;
		keyword2= NULL;
	}
	if(keyword3)
	{
		delete[]keyword3;
		keyword3 = NULL;
	}
	if(descriptions)
	{
		delete[]descriptions;
		descriptions = NULL;
	}

}
//initialize the dynamic array
bool music_entry::initialize(char artist_toadd[], char song_toadd[], char album_toadd[], char keyword1_toadd[], char keyword2_toadd[], char keyword3_toadd[], char description_toadd[])
{
	if(!artist_toadd || !song_toadd || !album_toadd || !keyword1_toadd ||!keyword2_toadd || !keyword3_toadd || !description_toadd) return false;
	if(artist)
	{
		delete[] artist;
		artist = NULL;
	}
	if(song)
	{
		delete[] song;
		song = NULL;
	}
	if(album)
	{
		delete[]album;
		album = NULL;

	}
	if(keyword1)
	{
		delete[]keyword1;
		keyword1= NULL;
	}
	if(keyword2)
	{
		delete[]keyword2;
		keyword2= NULL;
	}
	if(keyword3)
	{
		delete[]keyword3;
		keyword3 = NULL;
	}
	if(descriptions)
	{
		delete[]descriptions;
		descriptions = NULL;
	}
	artist = new char [strlen(artist_toadd)+1];
	strcpy (artist, artist_toadd);
	song = new char [strlen(song_toadd)+1];
	strcpy (song, song_toadd);
	album = new char [strlen(album_toadd)+1];
	strcpy (album, album_toadd);
	keyword1 = new char [strlen(keyword1_toadd)+1];
	strcpy (keyword1, keyword1_toadd);
	keyword2 = new char [strlen(keyword2_toadd)+1];
	strcpy (keyword2, keyword2_toadd);
	keyword3 = new char [strlen(keyword3_toadd)+1];
	strcpy (keyword3, keyword3_toadd);
	descriptions = new char [strlen(description_toadd)+1];
	strcpy (descriptions, description_toadd);
	return true;
}
//copy the information  into a single object
bool music_entry::copy(const music_entry & new_song)
{
	return initialize(new_song.artist, new_song.song, new_song.album,new_song.keyword1, new_song.keyword2, new_song.keyword3, new_song.descriptions);
}

//display the data
bool music_entry::display()const
{
	cout<< "Artist: "<<artist<<endl;
	cout<< "Song: "<<song<<endl;
	cout<< "Album: "<<album<<endl;
	cout<< "Keyword: "<<keyword1<<" , "<<keyword2<<" , "<<keyword3<<endl;
	cout<< "Descriptions: "<<descriptions<<endl<<endl;
}

//If there is a match with the name the user want to type with a pre-existing artist name return true
bool music_entry::artist_match(char to_compare[])
{
	if(strcmp(to_compare,artist)==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
//return true if artist in the binary search tree is greater than the new artist
bool music_entry::artist_less_than(char artist_compare[])
{
	if(strcmp(artist_compare, artist) < 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
// check if the the keyword being pass in match with the keyword in the binary search tree
bool music_entry::keywords_match(char keyword1_compare[],char keyword2_compare[], char keyword3_compare[])
{
	if(strcmp(keyword1, keyword1_compare) == 0 &&strcmp(keyword2, keyword2_compare) == 0 &&strcmp(keyword3, keyword3_compare) == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//return true if keywords in the binary search tree is greater than the new keywords 
bool music_entry::keywords_less_than(char keyword1_compare[],char keyword2_compare[], char keyword3_compare[])
{
	if(strcmp(keyword1_compare, keyword1) << 0 &&strcmp(keyword2_compare, keyword2) == 0 &&strcmp(keyword3_compare, keyword3) == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
