#include "step.h"
step_entry::step_entry()
{
	step = NULL;//Initialize step to Null
}
step_entry::~step_entry()
{
	//deallocate step
	if(step)
	{
		delete[] step;
		step = NULL;
	}

}

//initialize the dynamic array for the step
bool step_entry::create_entry(char step_toadd[])
{
 	if(!step_toadd) return false;
	if(step)
	{
		delete[] step;
		step = NULL;
	}
	step = new char [strlen(step_toadd)+1];
	strcpy (step, step_toadd);
	return true;
}

//copy the information  into a single object
bool step_entry::copy_entry(const step_entry & new_step)
{
	return create_entry(new_step.step);
}
//display the data in the graph
bool step_entry::display()const
{
	if(step == NULL)
	{
		return 0;
	}
	else
	{
		cout<<step<<endl;
		return 1;
	}
}
//compare if the key value match with the data in the adjacency list
bool step_entry::compare(char * key_value)
{
	if(strcmp(key_value, step) == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

