#include"step.h"

struct vertex
{
	step_entry * entry; //Null, if the vertex isn't set
	struct node * head; //edge list
};

struct node
{
	vertex * adjacent; //data that would be needed for a weighted graph
	node * next;
};

class table
{
	public:
		table(int size =5);//default constructor
		~table();//default destructor
		int display_all() const;//display all the vertices and the connection
		int display_adjacent(char * key_value);//display the adjacent vertices and the connection
		int insert_vertex(const step_entry & to_add);// insert a new vertices for a graph
		int insert_edge(char * current_vertex, char * to_attach);//connects two  vertices
		int find_location(char * key_value);// find the location of the key vaue
	private:
		vertex * adjacency_list;
		int list_size;
};
