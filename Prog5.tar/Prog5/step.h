#include <iostream>
#include <cctype>
#include <cstring>
#include <iostream>
//Jonan Doan
//The application allows the user to decide if they either want to add a vertex, connect two vertices with an edge, if they want to display and adjacency_list, if they want to display all.
//The user will then be prompted if they want to repeat a particular step and the application will enact based on their decision. The program will continue to run until the user
//type Q to quit. 
using namespace std;
class step_entry
{
	public:
		step_entry();//default constructor
		~step_entry();//default destructor

		//either initialize the data, inserting the data to the entry or displaying the content of the dynamic array
		bool create_entry(char step_toadd[]);
		bool copy_entry(const step_entry & a_new_entry);
		bool compare(char * key_value);
		bool display() const;
	private:
		char * step;// pointer that will hold what step to finish a program
	
};
