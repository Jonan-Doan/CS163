#include "graph.h"
table::table(int size)
{
	adjacency_list = new vertex[size];// initialize adjacency_list
	for(int i=0; i<size; ++i)
	{
		adjacency_list[i].head = NULL;// initialize all the head that belongs to each vertices
		adjacency_list[i].entry = NULL;//initialize all the entry that belongs to each vertices
	}
	list_size = size;// set the list size to 5
}

table::~table()
{
	for(int i = 0; i<list_size; ++i)// iterat throught the adjacency list
	{
		node * current = adjacency_list[i].head; // have a current pointer holding to each head pointer of the adjacency list
		while(current != NULL)// while current is not NULL
		{
			node * prev = current;
			current = current->next;
			delete prev;// delete all nodes
		}
	}
}	

int table::find_location(char * key_value)
{
	for(int i = 0; i<list_size; ++i) //iterate through the the adjacency list
		if(adjacency_list[i].entry->compare(key_value)) return i;// if the data match return the value where the data is found in the list 
	return -1;
}

int table::insert_vertex(const step_entry & to_add)
{
	for(int i = 0; i<list_size; ++i)//iterate through the adjacency list
	{
		if(adjacency_list[i].entry == NULL)// if the entry is empty
		{
			adjacency_list[i].entry = new step_entry;
			if(!adjacency_list[i].entry->copy_entry(to_add))// insert the data in the particular vertex and if it fails return 0
			{
				return 0;
			}

			return 1; // if it works return success
		}
	}
}

int table::insert_edge(char * current_vertex, char * to_attach)
{
	//find where the data is located
	int connection1= find_location(current_vertex);
	int connection2 = find_location(to_attach);
	if(connection1 == -1 || connection2== -1) return 0; // if the function fails return 0
	//connect the two vertices and return success
	node * temp = adjacency_list[connection1].head;
	adjacency_list[connection1].head = new node;
	adjacency_list[connection1].head->next = temp;
	adjacency_list[connection1].head->adjacent = &adjacency_list[connection2];
	return 1;
}
int table::display_adjacent(char * key_value)
{
	for(int i = 0; i<list_size; ++i)// iterate through the adjacency list
	{
		if(adjacency_list[i].entry->compare(key_value))// if the data match with one of the data in the list
		{
			adjacency_list[i].entry->display();//display vertex
			cout<<" -> ";//display connection
			node * current = adjacency_list[i].head;
			while(current)//while current is not Null
			{
				if(current->adjacent)// if there is an adjacent
				{
					if(!current->adjacent->entry->display())// display content and return 0 if there is a error
					{
						return 0;
					}
					
				}
				current = current->next;
			}
			return 1; //return success back to client
		}
	}
}	
int table::display_all() const
{
	if(!adjacency_list) //if their are no adjacency_list return 
	{
		return 0;
	}
	for(int i = 0; i<list_size; ++i)// iterate through the list
	{
		if(adjacency_list[i].entry) //as long as there are data in the entry
		{
			adjacency_list[i].entry->display();//display the vertex
			if(adjacency_list[i].head)// if the adjacency_list has a vertex
			{
				cout<<" -> ";// show the connection
			}
			node * curr = adjacency_list[i].head;
			while(curr)// while current is not Null
			{
				if(!curr->adjacent->entry->display())// display the content and return 0 if there is a error
				{
					return 0;
				}
				curr = curr->next;//traverse
			}
		}
	}
	return 1;//return success
}
