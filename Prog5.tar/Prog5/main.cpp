#include "graph.h"
using namespace std;

int main()
{
	table decision;//table object
	step_entry to_add, an_entry;
	char description[100], connected[100];
	char response;// char variable that will hold the letter if the user want to repeat their choice
 	char choice;// char variable that will hold the  letter of what the user want to do for the program
  	int error = 0;// integer variable that will prompt if there is something wrong with the program
	do
	{
		cout<<"Please type V if you want to add a new decision to a entry, Please type C if you want to add connection from one decision to another decision,"
		<<endl<<endl<<" Please type A if you want to display the direct connections of one decision, Please type D if you want to display all entry, Please "
		<<"type Q if you want to quit from thee program"<<endl;

		//recieve the choice decision the client want to initiate
		cin>>choice;
		cin.ignore(100, '\n');
		choice=toupper(choice);

		if(choice == 'V')// if the user want to add a new decision to a entry
		{
			do
			{
				cout<<"Please enter a step to solve a program."<<endl;

				//recieve the data the user want to put in the graph table
				cin.get(description, 100); cin.ignore(100, '\n');
				to_add.create_entry(description);
				error = decision.insert_vertex(to_add);//recieve success and error of the insert vertex function
				if(error == 0) // if there is an error
				{
					cout<<"There was something wrong with the insert. Please type again."<<endl;
				}
				cout<<"Please type Y if you want to type again and please type N if you don't want to type again."<<endl;

				// recieve the response if the user want to add a new entry or not
				cin>>response;
				cin.ignore(100, '\n');
				response=toupper(response);
			}while(response == 'Y');
		}
		if(choice == 'C')// if the user want connect two vertices with an edge
		{
			do
			{
				cout<<"Please enter two steps that you want to see connected."<<endl;
				
				//recieve two vertices to be connecteed by an edge
				cin.get(description, 100); cin.ignore(100, '\n');
				cin.get(connected, 100); cin.ignore(100, '\n');
				error = decision.insert_edge(description, connected); //recieve success and error of the insert edge function
				if(error == 0) // if there is an error
				{
					cout<<"There was something wrong with the connection. Please type again."<<endl;
				}
				cout<<"Please type Y if you want to type again and please type N if you don't want to type again."<<endl;

				//recieve the response if the user want to connect another two vertices together
				cin>>response;
				cin.ignore(100, '\n');
				response=toupper(response);
			}while(response == 'Y');
		}
		if(choice == 'A')//if the user want to display the  connection of two vertices
		{
			do
			{
				cout<<"Please enter a step to see what it is connected to."<<endl;
				// recieve what vertices the user wanted to see a connection to
				cin.get(description, 100); cin.ignore(100, '\n');
				error= decision.display_adjacent(description); // recieve success and error of the display adjacent function
				if(error == 0) // if there is an error
				{
					cout<<"There was something wrong with displaying the connection. Please type again."<<endl;
				}
				cout<<"Please type Y if you want to type again and please type N if you don't want to type again."<<endl;
				//recieve the response if the user want to display another connection again
				cin>>response;
				cin.ignore(100, '\n');
				response=toupper(response);
			}while(response == 'Y');
		}

		if(choice == 'D')//if the user want to display the all the content of the graph
		{
			cout<<"This is the contents of the table"<<endl<<endl;
			error =decision.display_all();//recieve success and error of the display_all function
			if(error == 0) // if there is an error
			{
				cout<<"There was something wrong with displaying the content. Please insert the data again first."<<endl;
			}

		}

	}while(choice !='Q');
	return 0;
}



